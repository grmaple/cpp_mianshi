## 关于C++标准库

![image-20200830180934807](C:\Users\xuyingfeng\AppData\Roaming\Typora\typora-user-images\image-20200830180934807.png)

容器(数据结构)

算法

迭代器

仿函数

### 确认支持C++11

```cpp
#include <iostream>
using namespace std;
int main() {
    cout<<__cplusplus<<endl;
}
```



